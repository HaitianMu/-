package com.example.prj.tools;

import java.io.Serializable;

public class industryData implements Serializable {
    public String name;
    public double value;
}
