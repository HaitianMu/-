package com.example.prj.users.service;

import com.example.prj.users.entity.Userinfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 09
 * @since 2023-09-02
 */
public interface IUserinfoService extends IService<Userinfo> {
}
