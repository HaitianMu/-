package com.example.prj.tools;

import java.io.Serializable;

public class areaData implements Serializable {
    public String name;
    public double value;
}
